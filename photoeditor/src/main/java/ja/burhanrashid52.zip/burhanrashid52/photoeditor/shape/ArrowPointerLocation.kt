package ja.burhanrashid52.photoeditor.shape

enum class ArrowPointerLocation { START, END, BOTH }