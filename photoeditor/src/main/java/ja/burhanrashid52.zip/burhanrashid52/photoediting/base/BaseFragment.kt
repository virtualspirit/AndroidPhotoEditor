package ja.burhanrashid52.photoediting.base

import androidx.fragment.app.Fragment

/**
 * @author [Burhanuddin Rashid](https://github.com/burhanrashid52)
 * @version 0.1.2
 * @since 5/25/2018
 */
abstract class BaseFragment(layoutId: Int) : Fragment(layoutId)